/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

/**
 *
 * @author fiacre
 */
public class Connection1 {
    Connection c=null;
    public void connect(){
        try {
             c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/web_tech", "postgres", "nyagatoma");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
