/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Student;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author fiacre
 */
public class StudentDao extends Connection1{
    public void createTable() {
        try {
            connect();
            Statement s = c.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS Student("
                    + "Id integer PRIMARY KEY NOT NULL ,"
                    + "firstName varchar(50) NOT NULL,"
                    + "lastName varchar(50) NOT NULL,"
                    + "department varchar(50) NOT NULL);";
            s.executeUpdate(sql);
            s.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public String saveStudent(Student s) {
        try {
            createTable();
            connect();
            PreparedStatement ps = c.prepareStatement("INSERT INTO student VALUES(?,?,?,?)");
            ps.setInt(1, s.getId());
            ps.setString(2, s.getFirstName());
            ps.setString(3, s.getLastName());
            ps.setString(4, s.getDepartment());
            ps.executeUpdate();
            ps.close();
            return "success";
        } catch (Exception e) {
             e.printStackTrace();
        }
        return "fali";
    }
    public List<Student> read(){
    PreparedStatement ps = null;
        List<Student> s=new ArrayList<>();
            try {
            connect();
            String sql = "select Id,firstName,lastName,department from student";

            Statement st = c.createStatement();
               ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                s.add(new Student(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getString(4)));
            }
            rs.close();
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        return s;

    }
    public String update(Student s){
    connect();
        if((!s.getId().equals(""))&&
                (!s.getFirstName().equals(""))&&
                (!s.getLastName().equals(""))&&
                (!s.getDepartment().equals(""))){
            try {
            PreparedStatement ps = c.prepareStatement(
                    "UPDATE STUDENT SET firstName = ?,"
                            + "lastName = ?,department = ? WHERE Id= ?");
            ps.setString(1, s.getFirstName());
            ps.setString(2, s.getLastName());
            ps.setString(3, s.getDepartment());
            ps.setInt(4, s.getId());
            ps.executeUpdate();
            
            ps.close();
            return "updated succesfully";
            } catch (SQLException e) {
            return "you must select certain row in table";
            }
        }
    return "failure";
    }
    public String delete(Student s) throws SQLException{
    connect();
        try {
            PreparedStatement ps = c.prepareStatement("DELETE FROM STUDENT WHERE Id = ?");
            
            ps.setInt(1, s.getId());
            
            ps.executeUpdate();
            
            ps.close();
            return "deleted successfully";
        } catch (Exception e) {
            return "select row firstly";
        }finally{
            c.close();
        }
    }
}
