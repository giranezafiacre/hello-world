/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author fiacre
 */
public class Student {
    private Integer Id;
    private String firstName;
    private String lastName;
    private String department;

    public Student() {
    }

    public Integer getId() {
        return Id;
    }

    public Student(Integer Id, String firstName, String lastName, String department) {
        this.Id = Id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
    }

    public void setId(Integer Id) {
        this.Id = Id;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }


    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
    
}
